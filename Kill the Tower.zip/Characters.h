#ifndef CHARACTERS_H
#define CHARACTERS_H
#include "Character.h"
#include "Berserker.h"
#include "Berserker.cpp"
#include "Rogue.h"
#include "Rogue.cpp"
#include "Scholar.h"
#include "Scholar.cpp"
#endif